/* Included by: RESTORE_PARAM SET_PARAM SHOW_PARAM STORE_PARAM */
extern Char *commands[];
extern Char *params[];
extern Char *prompts[];
extern Char *smodes[];
extern Char *sprompts[];
extern Char *offon[];
extern Char *cases[];
extern Char *caseprompts[];
extern Char *grepmodes[];
/* end */
