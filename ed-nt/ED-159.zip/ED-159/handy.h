/* Included by: CALC_LIMITS CHANGE_CASE EDIT INIT_TERIMINAL INSERT_WINDOW */
#define max(x,y) (((x)>=(y))?(x):(y))	/* maximum of two things */
#define min(x,y) (((x)<=(y))?(x):(y))	/* minimum of two things */
