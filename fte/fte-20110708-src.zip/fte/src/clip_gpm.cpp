/*    clip_gpm.cpp
 *
 *    Copyright (c) 1994-1996, Marko Macek
 *
 *    You may distribute under the terms of either the GNU General Public
 *    License or the Artistic License, as specified in the README file.
 *
 */

#include "fte.h"

int GetPMClip(int clipboard) {
    return 1;
}

int PutPMClip(int clipboard) {
    return 1;
}
