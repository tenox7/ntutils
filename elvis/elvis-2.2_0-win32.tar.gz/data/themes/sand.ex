try set textcursor=opaque
color normal black on white sand.xpm
if color("idle") != "like normal"
then color idle on linen sand.xpm
color cursor blue on navyblue
color selection boxed on orange
color bottom like normal
color toolbar white on sand.xpm
color tool saddlebrown on tan
color scrollbar like toolbar
color scroll like tool
color statusbar like toolbar
color status like tool
