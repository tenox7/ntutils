/* more.h */
/* Copyright 1995 by Steve Kirkendall */


BEGIN_EXTERNC
extern ELVBOOL morehit;
extern void morepush P_((WINDOW win, _CHAR_ special));
END_EXTERNC
